# 3DGS data prep — SLAM → COLMAP text

Convert Roborock long-sequence SLAM exports (NV12 images + TUM `pose.txt` in lidar body frame + RGB PCD) into **COLMAP text** layout for [3D Gaussian Splatting](https://github.com/graphdeco-inria/gaussian-splatting) training.

## Expected input layout

```
<input>/
├── pose.txt                          # TUM: ts tx ty tz qx qy qz qw (lidar body → world)
├── 0.01_downsample_rgb_0.01.pcd      # colored point map (binary PCD)
└── camera/
    ├── camera0/                      # default camera (NV12, 640×544)
    │   ├── 990123.yuv               # filename = timestamp in ms (optional extension)
    │   └── ...
    └── camera1/                      # optional (not exported by default)
```

Paths can be overridden with CLI flags if your tree differs.

## Requirements

- Python ≥ 3.9
- `numpy`, `Pillow` (`pip install numpy pillow`)

## Usage

```bash
cd /path/to/LocalizationTeam/projects/3dgs-data-prep

python3 slam_to_colmap.py \
  --input /mnt/data/roborock/60采集--长序列/ \
  --output /mnt/data/roborock/60采集--长序列_colmap/ \
  --downsample 20 \
  --max-pcd-points 100000 \
  --tolerance-ms 20
```

### Main options

| Flag | Default | Description |
|------|---------|-------------|
| `--input` | (required) | Dataset root |
| `--output` | (required) | COLMAP-style output root |
| `--downsample` | `20` | Keep every N-th matched frame |
| `--max-pcd-points` | `100000` | Random subsample cap for `points3D.txt` |
| `--tolerance-ms` | `20` | Max \|Δt\| between pose and image |
| `--cam-subdir` | `camera/camera0` | Relative path to NV12 frames |
| `--pose-file` | `pose.txt` | Relative path to TUM poses |
| `--pcd-file` | `0.01_downsample_rgb_0.01.pcd` | Relative path to PCD |
| `--width` / `--height` | `640` / `544` | NV12 resolution |
| `--jobs` | CPU count | Decoder worker processes |

Intrinsics and `T_cam_lidar` are **hardcoded** in `slam_to_colmap.py` for the calibrated Roborock rig (PINHOLE after rectification). Edit `DEFAULT_INTRINSICS` and `DEFAULT_T_CAM_LIDAR` if you use another calibration.

## Output layout

```
<output>/
├── images/
│   └── <sec_with_6_decimals>.png    # decoded from NV12; name encodes pose-aligned time
└── sparse/0/
    ├── cameras.txt
    ├── images.txt
    └── points3D.txt
```

## Verification (manual)

1. **Counts**
   ```bash
   ls <output>/images | wc -l
   ls <output>/sparse/0
   ```

2. **COLMAP `model_converter`** (if COLMAP is installed)
   ```bash
   mkdir -p <output>/sparse_bin/0
   colmap model_converter \
     --input_path <output>/sparse/0 \
     --output_path <output>/sparse_bin/0 \
     --output_type BIN
   ```
   No error → text model parses. (Some COLMAP builds segfault if the output directory does not exist — create it first.)

3. **GUI sanity** (trajectory + cameras)
   ```bash
   colmap gui --import_path <output>/sparse/0 --image_path <output>/images
   ```

## Coordinate conventions

- `pose.txt`: TUM quaternion order **qx qy qz qw**; pose is **lidar body in world** (`p_world = R * p_lidar + t`).
- COLMAP `images.txt`: **world → camera** (`p_cam = R * p_world + t`), quaternion **qw qx qy qz**.
- Script applies: `T_w2c = T_cam_lidar @ inv(T_world_lidar)`.

## Notes

- Only **cam0** is exported by default (single PINHOLE camera entry).
- `points3D.txt` uses PCD RGB; `TRACK` is omitted (empty). 3DGS uses XYZ + color for initialization.
- Frames without a pose match within `--tolerance-ms` are skipped (logged at end).
